const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const express = require('express');
const { body, validationResult } = require('express-validator');
const socketIO = require('socket.io');
const qrcode = require('qrcode');
const http = require('http');
const fileUpload = require('express-fileupload');
const axios = require('axios');
const mime = require('mime-types');
const port = process.env.PORT || 50990;
const app = express();
const server = http.createServer(app);
const io = socketIO(server);

function delay(t, v) {
  return new Promise(function(resolve) { 
      setTimeout(resolve.bind(null, v), t)
  });
}

app.use(express.json());
app.use(express.urlencoded({
extended: true
}));
app.use(fileUpload({
debug: false
}));
app.use("/", express.static(__dirname + "/"))

app.get('/', (req, res) => {
  res.sendFile('index.html', {
    root: __dirname
  });
});

// NUMEROS AUTORIZADOS
const permissaoBot = ["5515991236228@c.us", "5521981389149@c.us", "558186816992@c.us", "558196869075@c.us" ];

const client = new Client({
  authStrategy: new LocalAuth({ clientId: 'botShaka' }),
  puppeteer: { headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--no-first-run',
      '--no-zygote',
      '--single-process', // <- this one doesn't works in Windows
      '--disable-gpu'
    ] }
});

client.initialize();

io.on('connection', function(socket) {
  socket.emit('message', 'BotShaka - Iniciado');
  socket.emit('qr', './loading.svg');

client.on('qr', (qr) => {
    console.log('QR RECEIVED', qr);
    qrcode.toDataURL(qr, (err, url) => {
      socket.emit('qr', url);
      socket.emit('message', '© BotShaka QRCode recebido, aponte a câmera  seu celular!');
    });
});

client.on('ready', () => {
    socket.emit('ready', 'BotShaka Dispositivo pronto!');
    socket.emit('message', 'BotShaka Dispositivo pronto!');
    socket.emit('qr', './check.svg')	
    console.log('BotShaka Dispositivo pronto');
});

client.on('authenticated', () => {
    socket.emit('authenticated', 'BotShaka Autenticado!');
    socket.emit('message', 'BotShaka Autenticado!');
    console.log('BotShaka Autenticado');
});

client.on('auth_failure', function() {
    socket.emit('message', 'BotShaka Falha na autenticação, reiniciando...');
    console.error('BotShaka Falha na autenticação');
});

client.on('change_state', state => {
  console.log('BotShaka Status de conexão: ', state );
});

client.on('disconnected', (reason) => {
  socket.emit('message', 'BotShaka Cliente desconectado!');
  console.log('BotShaka Cliente desconectado', reason);
  client.initialize();
});
});

// Send message
app.post('/shaka-message', [
  body('number').notEmpty(),
  body('message').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req).formatWith(({
    msg
  }) => {
    return msg;
  });

  if (!errors.isEmpty()) {
    return res.status(422).json({
      status: false,
      message: errors.mapped()
    });
  }

  const number = req.body.number;
  const numberDDI = number.substr(0, 2);
  const numberDDD = number.substr(2, 2);
  const numberUser = number.substr(-8, 8);
  const message = req.body.message;

  if (numberDDI !== "55") {
    const numberShaka = number + "@c.us";
    client.sendMessage(numberShaka, message).then(response => {
    res.status(200).json({
      status: true,
      message: 'BotShaka Mensagem enviada',
      response: response
    });
    }).catch(err => {
    res.status(500).json({
      status: false,
      message: 'BotShaka Mensagem não enviada',
      response: err.text
    });
    });
  }
  else if (numberDDI === "55" && parseInt(numberDDD) <= 30) {
    const numberShaka = "55" + numberDDD + "9" + numberUser + "@c.us";
    client.sendMessage(numberShaka, message).then(response => {
    res.status(200).json({
      status: true,
      message: 'BotShaka Mensagem enviada',
      response: response
    });
    }).catch(err => {
    res.status(500).json({
      status: false,
      message: 'BotShaka Mensagem não enviada',
      response: err.text
    });
    });
  }
  else if (numberDDI === "55" && parseInt(numberDDD) > 30) {
    const numberShaka = "55" + numberDDD + numberUser + "@c.us";
    client.sendMessage(numberShaka, message).then(response => {
    res.status(200).json({
      status: true,
      message: 'BotShaka Mensagem enviada',
      response: response
    });
    }).catch(err => {
    res.status(500).json({
      status: false,
      message: 'BotShaka Mensagem não enviada',
      response: err.text
    });
    });
  }
});


// Send media
app.post('/shaka-media', [
  body('number').notEmpty(),
  body('caption').notEmpty(),
  body('file').notEmpty(),
], async (req, res) => {
  const errors = validationResult(req).formatWith(({
    msg
  }) => {
    return msg;
  });

  if (!errors.isEmpty()) {
    return res.status(422).json({
      status: false,
      message: errors.mapped()
    });
  }

  const number = req.body.number;
  const numberDDI = number.substr(0, 2);
  const numberDDD = number.substr(2, 2);
  const numberUser = number.substr(-8, 8);
  const caption = req.body.caption;
  const fileUrl = req.body.file;

  let mimetype;
  const attachment = await axios.get(fileUrl, {
    responseType: 'arraybuffer'
  }).then(response => {
    mimetype = response.headers['content-type'];
    return response.data.toString('base64');
  });

  const media = new MessageMedia(mimetype, attachment, 'Media');

  if (numberDDI !== "55") {
    const numberShaka = number + "@c.us";
    client.sendMessage(numberShaka, media, {caption: caption}).then(response => {
    res.status(200).json({
      status: true,
      message: 'BotShaka Imagem enviada',
      response: response
    });
    }).catch(err => {
    res.status(500).json({
      status: false,
      message: 'BotShaka Imagem não enviada',
      response: err.text
    });
    });
  }
  else if (numberDDI === "55" && parseInt(numberDDD) <= 30) {
    const numberShaka = "55" + numberDDD + "9" + numberUser + "@c.us";
    client.sendMessage(numberShaka, media, {caption: caption}).then(response => {
    res.status(200).json({
      status: true,
      message: 'BotShaka Imagem enviada',
      response: response
    });
    }).catch(err => {
    res.status(500).json({
      status: false,
      message: 'BotShaka Imagem não enviada',
      response: err.text
    });
    });
  }
  else if (numberDDI === "55" && parseInt(numberDDD) > 30) {
    const numberShaka = "55" + numberDDD + numberUser + "@c.us";
    client.sendMessage(numberShaka, media, {caption: caption}).then(response => {
    res.status(200).json({
      status: true,
      message: 'BotShaka Imagem enviada',
      response: response
    });
    }).catch(err => {
    res.status(500).json({
      status: false,
      message: 'BotShaka Imagem não enviada',
      response: err.text
    });
    });
  }
});

client.on('message', async msg => {
  if (msg.body === null) return;
    let comando = msg.body.split(" ");
    if (comando[0] === "!aviso") {
      // MENÇÃO FANTASMA
      let chat = await msg.getChat();
      if (chat.isGroup) {
        let admin = permissaoBot.find((autor) => autor === msg.author);
        if (admin !== undefined) {
          let mensagem = msg.body.replace(comando[0], "").trim();
          try {
            const serializedArray = chat.participants.map(
              ({ id: { _serialized } }) => _serialized
            );
            client.sendMessage(msg.from,{ caption: "Marcando todos escondido" },{ mentions: serializedArray });
            delay(3000).then(async function () {
              client.sendMessage(msg.from, mensagem, {mentions: serializedArray,});
            });
          } catch (e) {
            console.log(e);
          }
        } else {
          console.log("usuario " + msg.author + " não pode utilizar essa função.");
        }
      }
    }

  // Marcar Todos
  if (comando[0] === "!todos") {
    const chat = await msg.getChat();
    if (chat.isGroup) {
      let text = "";
      let mentions = [];

      for (let participant of chat.participants) {
        const contact = await client.getContactById(participant.id._serialized);

        mentions.push(contact);
        text += `@${participant.id.user} `;
      }

      await chat.sendMessage(text, { mentions });
    }
  }
});

client.on("message", (message) => {
  if (message.body === "!ping") {
    message.reply("pong");
  }
});

server.listen(port, function() {
        console.log('Aplicação rodando na porta *: ' + port + ' . Acesse no link: http://localhost:' + port);
});
